# Automatically created. Please do not edit.
__version__ = u'1.0.24'

__author__ = u'Avi Yaeli'
